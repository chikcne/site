from py3nj import wigner6j
import math
import random
import numpy as np
import scipy.constants as constants 

# Returns a list of possible F values for a given combination of I and J.
# twiceF here is actually 2*F
def populateF(I, J):
    Fmin = abs(I - J)
    Fmax = abs(I + J)
    twiceF = []
    U = Fmin
    for count in range( int(Fmax-Fmin) + 1 ):
        twiceF.append(int(2*U))
        U += 1
    return twiceF

# Same as populateF but for a list of J values.
def populateFlist(I, Jlist):
    twiceFlist = []
    for J in Jlist:
        Fmin = abs(I - J)
        Fmax = abs(I + J)
        twiceF = []
        U = Fmin
        for count in range( int(Fmax-Fmin) + 1 ):
            twiceF.append(int(2*U))
            U += 1
        twiceFlist.append(twiceF)
    return twiceFlist


# This function produces a list of omega_FF' values for the corresponding F and F'
# each element in the list corresponds to an F, and each sub-element is in ascending order for F'.
def omegaFunction(F, A, gf=1.0):
    Fx, Fy = np.meshgrid(F,F)
    omega = gf * A * np.pi * ( (Fy/2)*((Fy/2) + 1) - (Fx/2)*((Fx/2) + 1) ) 
    return omega

# The Goldring formula is taken from equation (9) of the 2013 Stuchbery paper.
# 1-d subarrays are produced so that it is compatible with py3nj.wigner6j().
def GoldringConst(k, I, Jlist, twiceFlist, Alist, gf=1.0):
    ConstArrayList = []
    omegaArrayList = []
    for i in range(len(Jlist)):
        Fx = np.tile(twiceFlist[i],len(twiceFlist[i]))
        Fy = np.repeat(twiceFlist[i],len(twiceFlist[i]))
        ConstArrayList.append( (Fy + 1) * (Fx + 1) / (2*Jlist[i] + 1) * (wigner6j( Fy, Fx, \
        2*np.full(len(Fx),k), 2*np.full(len(Fx),int(I)), 2*np.full(len(Fx) \
        ,int(I)), np.full(len(Fx),int(2*Jlist[i])) )) ** 2 )
        omegaArrayList.append( gf * Alist[i] * np.pi * ( (Fy/2)*((Fy/2) + 1) - (Fx/2)*((Fx/2) + 1) ) )
    return ConstArrayList, omegaArrayList

# This is 'partial' because it doesn't compute the omegas: Suitable for differing A_J
# Each array in the list needs to be summed over later
# Each element in the output corresponds to a J
# Each subelement in the output corresponds to an FF'
def GoldringConst_partial(k, I, Jlist, twiceFlist):
    ConstArrayList = []
    for i in range(len(Jlist)):
        Fx = np.tile(twiceFlist[i],len(twiceFlist[i]))
        Fy = np.repeat(twiceFlist[i],len(twiceFlist[i]))
        ConstArrayList.append( (Fy + 1) * (Fx + 1) / (2*Jlist[i] + 1) * (wigner6j( Fy, Fx, \
        2*np.full(len(Fx),k), 2*np.full(len(Fx),int(I)), 2*np.full(len(Fx) \
        ,int(I)), np.full(len(Fx),int(2*Jlist[i])) )) ** 2 )
    return ConstArrayList

# each element in the output corresponds to a J
# this implementation makes it so that the index of the subelement corresponds to the same A_J
# each subsubelement in the output corresponds to an FF' combination
def omega_Lorentz(twiceFlist, Jlist, gf=1.0, cauchy_factor=1e3, cauchy_size=1000000):
    # Lorentz_array is the hyperfine magnetic field B distributed on a Lorentz distribution
    Lorentz_array = cauchy_factor * np.random.normal(size=cauchy_size)[:,None]
    omegaArrayList = []
    for j,twiceF in enumerate(twiceFlist):
        Fx = np.tile(twiceF,len(twiceF))
        Fy = np.repeat(twiceF,len(twiceF))
        omegaArrayList.append( (gf * Lorentz_array *  5.050783699e-27 / constants.hbar / Jlist[j] / 2 * ( (Fy/2)*((Fy/2) + 1) - (Fx/2)*((Fx/2) + 1) )) )
    return omegaArrayList

# repeat of the above, but leave out the gf factor (useful for when varying gf)
def omega_Lorentz_nogf(twiceFlist, Jlist, cauchy_factor=1e10, cauchy_size=1000000):
    Lorentz_array = cauchy_factor * np.random.standard_cauchy(cauchy_size)[:,None]
    omegaArrayList = []
    for j,twiceF in enumerate(twiceFlist):
        Fx = np.tile(twiceF,len(twiceF))
        Fy = np.repeat(twiceF,len(twiceF))
        omegaArrayList.append( (Lorentz_array *  5.050783699e-27 / constants.hbar / Jlist[j] / 2 * ( (Fy/2)*((Fy/2) + 1) - (Fx/2)*((Fx/2) + 1) )) )
    return omegaArrayList


# This function represents the 'decay' via an E1 transmission, so J = +- 1.
# Only works if each element in Jlist is separated by exactly 1.
def atomic_decay(list_length, i):
    if (i == 0):
        if random.randrange(2) == 1:
            i = 1
    elif (i + 1 == list_length):
        if random.randrange(2) == 1:
            i -= 1
    else:
        rnd = random.randrange(3)
        if (rnd == 1):
            i += 1
        elif (rnd == 2):
            i -= 1
    return i

# Generates the events beforehand without calculating the Gk
# t_a_listlist[n][-1] corresponds to the nuclear lifetime of the nth event

def pretime(tau_n, tau_a, number_of_trials, fixed_t_n=False):
    if fixed_t_n == True:
        t_n_array = np.full(number_of_trials,tau_n)
    else:
        t_n_array = -tau_n * np.log(1-np.random.rand(number_of_trials))
    t_a_listlist = []
    t_a_array = -tau_a * np.log(1-np.random.rand(125))
    # n indexes through t_a_array
    n = 0
    for t_n in t_n_array:
        t_a_list = [0.0]
        t_a_sum = 0.0
        while t_a_sum < t_n:
            try:
                t_a_list.append(t_a_array[n])
            except IndexError:
                t_a_array = -tau_a * np.log(1-np.random.rand(125))
                t_a_list.append(t_a_array[0])
                n = 0
            t_a_sum += t_a_array[n]
            n += 1
        # this line makes it so that the last t_a does not go past the nuclear survival time
        t_a_list[-1] -= t_a_sum - t_n
        t_a_listlist.append(t_a_list)
    # Each element (list) in t_a_listlist corresponds to one event (or nuclear survival time)
    return t_a_listlist

# This variant is for time "integrals", and no tracking of intermediate values.
# Outputs Gk as a function of tau_n, the nuclear lifetime
def GkCalcInt(t_a_listlist, GoldringConstArrayList, omegaArrayList):
    Gk_total = 0.0
    # Calculate the Gk at the end of each atomic decay for each event
    for t_a_list in t_a_listlist:
        # Initialising the for loop:
        # choose a random atomic state to start with:
        i = random.randrange(len(GoldringConstArrayList))
        l_array = np.random.randint(len(omegaArrayList[0]),size=len(t_a_list)+1)
        Gk = 1.0
        for j,t_a in enumerate(t_a_list):
            Gk = Gk * np.sum( GoldringConstArrayList[i] * np.cos(omegaArrayList[i][l_array[j]] * t_a) )
            i = atomic_decay(len(GoldringConstArrayList),i)
        Gk_total += Gk
    Gk_mean = Gk_total / len(t_a_listlist)
    return Gk_mean

# Outputs Gk as a function of t
def GkCalc_differential(t_a_listlist, GoldringConstArrayList, omegaArrayList, time_array):
    Gk_listlist = []
    # this array keeps track of the number of transitions at each time
    transitions_arraylist = []
    # main loop goes through each event
    for t_a_list in t_a_listlist:
        # t_acc_array is t_a_array but accumulative and is an array
        t_acc_array = np.cumsum(t_a_list)
        # Get the indices to "match up" t_a and time
        index_list = []
        for time in time_array:
            if time < t_acc_array[-1]:
                # Get the index of the last element in t_acc_array that is smaller than time
                index_list.append( np.nonzero(t_acc_array < time)[0][-1] )
        # Calculate the Gk at the end of each atomic decay
        # Initialising the for loop:
        i = random.randrange(len(GoldringConstArrayList))
        Gk = 1.0
        Gka_list = [1.0]
        i_list = [i]
        Gk_list = []
        l_array = np.random.randint(len(omegaArrayList[0]),size=len(t_a_list)+1)
        for j,t_a in enumerate(t_a_list):
            # l is the index which picks out the "A_J"
            Gk = Gk * np.sum( GoldringConstArrayList[i] * np.cos(omegaArrayList[i][l_array[j]] * t_a) )
            i = atomic_decay(len(GoldringConstArrayList),i)
            Gka_list.append(Gk)
            i_list.append(i)

        # Now we can calculate the Gk at each time
        counter = 0
        for j,index in enumerate(index_list):
            counter += 1
            t_int = time_array[j] - t_acc_array[index]
            Gk = Gka_list[index] * np.sum( GoldringConstArrayList[i_list[index]] * np.cos(omegaArrayList[i_list[index]][l_array[index]] * t_int) )
            Gk_list.append(Gk)
        while counter < len(time_array):
            counter += 1
            Gk_list.append(Gka_list[-1])
        Gk_listlist.append(Gk_list)
        transitions_arraylist.append(index_list)
    Gk_mean_array = np.mean(Gk_listlist,0)
    mean_transitions_array = np.mean(transitions_arraylist,0)
    return Gk_mean_array, mean_transitions_array

# Fix the atomic lifetime, vary the g-factor
# We vary g through the same set of events
def MCG_g(k,I,Jlist,tau_n,tau_a,number_of_trials=1000,initial=0.0, final=1.0, steps=100,cauchy_factor=650,cauchy_size=100000, fixed_t_n=False):
    twiceFlist = populateFlist(I, Jlist)
    Gk_mean_list = []
    gf_list = np.linspace(initial,final,num=steps)
    t_a_listlist = pretime(tau_n, tau_a, number_of_trials,fixed_t_n=fixed_t_n)
    GoldringConstArrayList = GoldringConst_partial(k, I, Jlist, twiceFlist)
    omegaArrayList = omega_Lorentz_nogf(twiceFlist,Jlist,cauchy_factor=cauchy_factor,cauchy_size=cauchy_size)
    for gf in gf_list:
        Gk_mean_list.append(GkCalcInt(t_a_listlist, GoldringConstArrayList, [i*gf for i in omegaArrayList]))
    return gf_list, Gk_mean_list

# Fix the g-factor, vary the atomic lifetime
def MCG_tau_a(k,I,Jlist,tau_n,gf=1.0,number_of_trials=1000,initial=1e-12, final=50e-12, steps=100,cauchy_factor=650,cauchy_size=100000, fixed_t_n=False):
    twiceFlist = populateFlist(I, Jlist)
    Gk_mean_list = []
    tau_a_array = np.linspace(initial,final,num=steps)
    GoldringConstArrayList = GoldringConst_partial(k, I, Jlist, twiceFlist)
    omegaArrayList = omega_Lorentz(twiceFlist, Jlist, gf=gf,cauchy_factor=cauchy_factor,cauchy_size=cauchy_size)
    for tau_a in tau_a_array:
        t_a_listlist = pretime(tau_n, tau_a, number_of_trials,fixed_t_n=fixed_t_n)
        Gk_mean_list.append(GkCalcInt(t_a_listlist, GoldringConstArrayList, omegaArrayList))
    return tau_a_array, Gk_mean_list

# transitions is the number of transitions output as a list
def MCG_differential(k,I,Jlist,tau_n,tau_a,gf=1.0,number_of_trials=1000,initial=1e-12, final=50e-12, steps=100,cauchy_factor=650,cauchy_size=100000, fixed_t_n=False):
    # Each element in twiceF contains the possible 2*F values for the corresponding J value.
    twiceFlist = populateFlist(I, Jlist)
    GoldringConstArrayList = GoldringConst_partial(k, I, Jlist, twiceFlist)
    time_array = np.linspace(initial,final,num=steps)
    omegaArrayList = omega_Lorentz(twiceFlist, Jlist, gf=gf,cauchy_factor=cauchy_factor,cauchy_size=cauchy_size)
    t_a_listlist = pretime(tau_n, tau_a, number_of_trials,fixed_t_n=fixed_t_n)
    Gk_mean_array, transitions_array = GkCalc_differential(t_a_listlist, GoldringConstArrayList, omegaArrayList, time_array)
    return time_array, Gk_mean_array, transitions_array