This uses the py3nj library from Keisuke Fujii:
https://github.com/fujiisoup/py3nj

You need a fortran compiler installed in your environment, and you might also need Microsoft Visual C++ 14.0.