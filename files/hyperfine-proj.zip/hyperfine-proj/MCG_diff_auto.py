#%%
from MCG_module import MCG_g, MCG_tau_a, MCG_differential
import csv
import numpy as np
import matplotlib.pyplot as plt
plt.style.use('default')
from pathlib import Path

# This function helps find the index of closest element to a value in an array
def find_nearest(array, value):
    i = np.abs(array - value).argmin()
    return i

def auto_Gkdiff(tau_a,gf,cauchy_factor,initial,final,parent_directory,steps):
    # fixed_t_n=True emulates the plunger model
    fixed_t_n=True
    number_of_trials = 10000
    if fixed_t_n==True:
        tau_n = final+2e-12
    cauchy_size=100000

    time_array, Gk_mean_array, transitions = MCG_differential(k,I,Jlist,tau_n,tau_a,gf,number_of_trials,initial, final, steps,cauchy_factor,cauchy_size,fixed_t_n)
    filename = f'G{k}diff{tau_a *1e12}ps_{gf}gf_{initial*1e12}ps-{final*1e12}ps'

    plt.close()
    plt.ioff()
    plt.plot(time_array*1e12,Gk_mean_array)
    plt.xlabel('time, $t$ (ps)')
    plt.ylabel(f'$G_{k}$')
    if fixed_t_n==True:
        plt.figtext(0.99, -0.06, f"$\\tau_a$: {tau_a*1e12:.4} ps   $g$: {gf}    initial $t$: {initial*1e12:.4} ps    final $t$: {final*1e12:.4} ps\n cauchy factor:{cauchy_factor}    # of trials: {number_of_trials}",horizontalalignment='right')
    else:
        plt.figtext(0.99, -0.06, f"$\\tau_n$: {tau_n*1e12:.4} ps    $\\tau_a$: {tau_a*1e12:.4} ps   $g$: {gf}    initial $t$: {initial*1e12:.4} ps    final $t$: {final*1e12:.4} ps\n cauchy factor:{cauchy_factor}    # of steps: {steps}    # of trials: {number_of_trials}",horizontalalignment='right')
    linearfig = plt.gcf()

    plt.close()
    plt.ion()
    plt.plot(time_array*1e12,Gk_mean_array)
    plt.xlabel('time, $t$ (ps)')
    plt.ylabel(f'$G_{k}$')
    plt.ylim(0,1.2)
    if fixed_t_n==True:
        plt.figtext(0.99, -0.06, f"$\\tau_a$: {tau_a*1e12:.4} ps   $g$: {gf}    initial $t$: {initial*1e12:.4} ps    final $t$: {final*1e12:.4} ps\n     cauchy factor:{cauchy_factor}    # of steps: {steps}    # of trials: {number_of_trials}",horizontalalignment='right')
    else:
        plt.figtext(0.99, -0.06, f"$\\tau_n$: {tau_n*1e12:.4} ps    $\\tau_a$: {tau_a*1e12:.4} ps   $g$: {gf}    initial $t$: {initial*1e12:.4} ps    final $t$: {final*1e12:.4} ps\n cauchy factor:{cauchy_factor}    # of steps: {steps}    # of trials: {number_of_trials}",horizontalalignment='right')
    linearfig_unzoomed = plt.gcf()

    print(f'cf= {cauchy_factor}')

    # This cell plots the logarithmic plot of the above.
    plt.close()
    a,b = np.polyfit(time_array,np.log(Gk_mean_array),1)
    if b < 0:
        bphrase = f"- {abs(b):.3}"
    else:
        bphrase = f"+ {abs(b):.3}"

    if fixed_t_n == True:
        plt.figtext(0.99, -0.06, f"$\\tau_a$: {tau_a*1e12:.4} ps   $g$: {gf}    initial $t$: {initial*1e12:.4} ps    final $t$: {final*1e12:.4} ps\n     cauchy factor:{cauchy_factor}    # of steps: {len(time_array)}    # of trials: {number_of_trials}",horizontalalignment='right')
    else:
        plt.figtext(0.99, -0.06, f"$\\tau_n$: {tau_n*1e12:.4} ps    $\\tau_a$: {tau_a*1e12:.4} ps   $g$: {gf}    initial $t$: {initial*1e12:.4} ps    final $t$: {final*1e12:.4} ps\n cauchy factor:{cauchy_factor}    # of steps: {len(time_array)}    # of trials: {number_of_trials}",horizontalalignment='right')
    plt.xlabel('time, $t$ (ps)')
    plt.ylabel(f'ln($G_{k}$)')
    plt.plot(time_array*1e12,np.log(Gk_mean_array),label=f'ln($G_{k}$) = {a:.3} $t$ {bphrase}')
    plt.legend()
    logfig = plt.gcf()
    print(f"steps = {steps}; gf = {gf}; tau_a = {tau_a*1e12}ps; ln(G_{k}) = {a:.3} t {bphrase}")

    # Save everything

    Path(f"{parent_directory}/{filename}").mkdir(parents=True)
    with open(Path(f'{parent_directory}/{filename}/{filename}.csv'), 'w', newline='') as csvFile:
        writer = csv.writer(csvFile)
        writer.writerows(zip(time_array,Gk_mean_array,transitions))
    #linearfig.savefig(Path(f'{parent_directory}/{filename}/{filename}.pdf'),bbox_inches = 'tight')
    #logfig.savefig(Path(f'{parent_directory}/{filename}/{filename}_log.pdf'),bbox_inches = 'tight')
    #linearfig_unzoomed.savefig(Path(f'{parent_directory}/{filename}/{filename}_unzoomed.pdf'),bbox_inches = 'tight')
    linearfig_unzoomed.savefig(Path(f'{parent_directory}/{filename}/{filename}_unzoomed.svg'),bbox_inches = 'tight')
    linearfig.savefig(Path(f'{parent_directory}/{filename}/{filename}.svg'),bbox_inches = 'tight')
    logfig.savefig(Path(f'{parent_directory}/{filename}/{filename}_log.svg'),bbox_inches = 'tight')

    # Save this a value
    with open(Path(f'{parent_directory}/a-values_plunger.csv'), 'a') as csvFile:
        csvFile.write(f"{k},{tau_a}, {gf}, {time_array[0]}, {time_array[-1]},{len(time_array)},,{a}\n")
        
    print(f"Files saved to directory '{Path(f'{parent_directory}/{filename}')}'")

#%%
# I is the nuclear spin.
I = 2.0
# J are the atomic spins, they must be apart by 1!
Jlist = [0.5,1.5,2.5]
# A are the corresponding hyperfine constants in Hz for each J. Also known as A_J.
# Since we are switching to Lorentz distribution along A we don't need this any more.
#Alist = [27589461401.0,5141611679.0,569522893.39]
k = 2
tau_a_list = np.array([0.5,1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,15.0,30.0,100.0])* 1e-12
#tau_a_list = np.array([100.0])* 1e-12
#tau_a_list = np.array([1.0])* 1e-12
gf_list = [0.2,0.4,0.6,0.8,1.0,1.2,1.4,1.6,1.8,2.0]
cauchy_factor=10000
initial = 0.01e-12
final = 20e-12
parent_directory='Gk_diff_auto_modified 10000'
steps = 60

for cauchy_factor in [1500,150,5000]:
    for tau_a in tau_a_list:
        for gf in gf_list:
            parent_directory=f'Gk_diff_auto_modified {cauchy_factor}'
            auto_Gkdiff(tau_a,gf,cauchy_factor,initial,final,parent_directory,steps)
            print(f"tau_a: {tau_a}  gf: {gf} done!")

# %%
